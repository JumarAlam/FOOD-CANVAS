
(".submit").click(function(){
	return false;
})
