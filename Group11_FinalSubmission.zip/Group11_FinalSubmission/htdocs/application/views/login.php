<!DOCTYPE html>
<html>
<head>
          <meta name="viewport" content="width=device-width, initial-scale=1">

    <meta name="viewport" content="width=device-width, initial-scale=1">
     <link rel="stylesheet" href="<?php echo base_url()?>//assets/css/signup.css">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="<?php echo base_url()?>//assets/https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css"> 
    <link rel="stylesheet" type="text/css" href="<?php echo base_url()?>//assets/css/font-awesome.min.css">
    <link rel="stylesheet" href="<?php echo base_url()?>//assets/css/bootstrap.min.css">
    <link rel="stylesheet" herf="<?php echo base_url()?>//assets/css/bootstrap.css">
    <link rel="stylesheet" href="<?php echo base_url()?>//assets/css/style.css">
    <link rel="stylesheet" type="text/css" href="https://fonts.googleapis.com/css?family=Satisfy|Bree+Serif|Candal|PT+Sans">
     <script src="<?php echo base_url()?>//assets/https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src=" <?php echo base_url()?>//assets/https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>


       <title> FOOD CANVAS </title>    
<style>
header
{
    background-image:linear-gradient(rgba(0,0,0,.1),rgba(0,0,0,.1)),url( <?php echo base_url()?>//assets/img/banner-bg.jpg);
    height: 100vh;
    background-position: center;
    background-size: cover
}


</style>        

<body>
    <header>
    
   
            
    <div class="row">
        <div class="logo">
        <img src="<?php echo base_url()?>//assets/img/LOGONEWARIEL.png">
        </div>
        <ul class="main-nav">
            <li><a href="home">HOME</a></li>
            <li><a href="">RESTAURANT AROUND YOU</a></li>
            <li><a href="">CONTACT US</a></li>
            <li><a href="login">LOG IN</a></li>
            <li><a href="signup">SIGN UP</a></li>
            
        
        
        </ul>
        
        </div>

          <br><br><br>
        <div class="row">
            <div class="col-sm-5">
                    <div class="container">
                        <div class="text4">
                            <h1><b><br>  FOOD IS FOR LIFE!!  <br>   EAT HEALTHY!   STAY HEALTHY!!<br></b></h1>
                        </div>
                                
                    </div>
            </div>
            <div class="col-sm-7">
                <div class="container">
            <form id="msform" action="loginprocess" method="post">
              <!-- fieldsets -->
              <fieldset>
                <h2 class="fs-title">Log inot your account</h2>
                  <hr>
                <h3 class="fs-subtitle"></h3>
                <input type="text" name="email" placeholder="Email" />
                <input type="password" name="pass" placeholder="Password" />
                <input type="submit" name="submit" class="submit action-button" value="Log In!!" />
    
              </fieldset>
  
            </form>    
                </div>
            </div>
            
            
            
    
        
    <script src="<?php echo base_url()?>//assets/js/signup.js"></script>
            </header>
        <!-- multistep form -->
            <section id="contact">
                  <div class="container-full">
                    <div class="row">
                      <div class="col-lg-8 mx-auto text-center">
                        <h2 class="section-heading">ABOUT US!</h2>
                        <hr class="my-4">
                        <p class="mb-5">This website was made for Database Management System.<br> Still under construction.<br> MADE BY <b>JUMAR, TANJEEB AND ZAHID</b></p>
                      </div>
                    </div>
                    <div class="row">
                      <div class="col-lg-4 ml-auto text-center">
                        <i class="fa fa-phone fa-3x mb-3 sr-contact"></i>
                        <p>123-456-6789</p>
                      </div>
                      <div class="col-lg-4 mr-auto text-center">
                        <i class="fa fa-envelope-o fa-3x mb-3 sr-contact"></i>
                        <p>
                          <a href="mailto:your-email@your-domain.com">jumar.alam@northsouth.edu</a>
                        </p>
                      </div>
                    </div>
                  </div>
                </section>
                </body>




</html>