<!DOCTYPE html>
<html>
<head>
     <meta name="viewport" content="width=device-width, initial-scale=1">

    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href=" <?php echo base_url()?>//assets/ https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css"> 
    <link rel="stylesheet" type="text/css" href=" <?php echo base_url()?>//assets/css/font-awesome.min.css">
    <link rel="stylesheet" href="<?php echo base_url()?>//assets/css/bootstrap.min.css">
    <link rel="stylesheet" herf="<?php echo base_url()?>//assets/css/bootstrap.css">
    <link rel="stylesheet" href="<?php echo base_url()?>//assets/css/style.css">
    <link rel="stylesheet" type="text/css" href= " <?php echo base_url()?>//assets/fonts/https://fonts.googleapis.com/css?family=Satisfy|Bree+Serif|Candal|PT+Sans">
     <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>


       <title> FOOD CANVAS </title>    
<style>
header
{
    background-image:linear-gradient(rgba(0,0,0,.1),rgba(0,0,0,.1)),url( <?php echo base_url()?>//assets/img/3.jpg);
    height: 70vh;
    background-position: center;
    background-size: cover
}


</style>        

<body>
    <header>
    
   
            
    <div class="row">
        <div class="logo">
        <img src="<?php echo base_url()?>//assets/img/LOGONEWARIEL.png">
        </div>
        <ul class="main-nav">
            <li><a href="home">HOME</a></li>
            <li><a href="">RESTAURANT AROUND YOU</a></li>
            <li><a href="">CONTACT US</a></li>
            <li><a href="login">LOG IN</a></li>
            <li><a href="signup">SIGN UP</a></li>
            
        
        
        </ul>
        
        </div>
    <div class = "first">
        <h1>WELCOME TO FOOD CANVAS</h1>
        <h2>Find the best restaurants and cafes in Dhaka</h2>
        
        <form class="example" action="#" style="margin:auto;max-width:700px">
  <input type="text" placeholder="Search.." name="search2">
  <button type="submit"><i class="fa fa-search"></i></button>
        </form>

        
        </div>
        
        
    
    </header>
    
    <hr class="my-4">


          <div class="row">
            
                <div class ="container-bg">
                            <div class="col-lg-6">
                                <div class="container">
                                  <img src=" <?php echo base_url()?>//assets/img/onlineordering.jpg" alt="Avatar" class="image" style="width:550px">
                                  <a href="order">
                                      <div class="middle">
                                      
                                        <div class="text">Order Food</div>
                                      
                                      </div>
                                  </a>
                                </div>
                            </div>
                            <div class="col-lg-6">
                                <div class="container">
                                    <img src=" <?php echo base_url()?>//assets/img/reservation.jpg" alt="Avatar" class="image" style="width:550px">
                                    <a href="reservation">
                                        <div class="middle">
                                            <div class="text">Book A Table</div>
                                        </div>
                                    </a>
                                </div>

                            </div>
                
                </div>
             </div>
        
    
        <hr>
    <div class="container">
        <div class="row">
          <div class="col-lg-12 text-center">
            <h1 class="section-heading">TRENDING FOODS</h1>
            <hr class="my-4">
          </div>
        </div>
      </div>
    
                    
        
                        <div class="row">
                            <div class="col-sm-3">
                                <div class="container">
                                    <img src=" <?php echo base_url()?>//assets/img/s1.jpg" alt="Avatar" class="image2" style="width: 125%"/>
                                        <div class="overlay">
                                        <div class="text2"><b>Italian Food</b></div>
                                        </div>
                                </div>
                            </div>
                            <div class="col-sm-3">
                                <div class="container">
                                    <img src=" <?php echo base_url()?>//assets/img/s2.jpg" alt="Avatar" class="image2" style="width: 125%"/>
                                        <div class="overlay">
                                        <div class="text2"><b>Indian Food</b></div>
                                        </div>
                                </div>
                            </div>
                            <div class="col-sm-3">
                                <div class="container">
                                    <img src=" <?php echo base_url()?>//assets/img/s3.jpg" alt="Avatar" class="image2" style="width: 125%"/>
                                        <div class="overlay">
                                        <div class="text2"><b>French Food</b></div>
                                        </div>
                                </div>
                            </div>
                            <div class="col-sm-3">
                                <div class="container">
                                    <img src=" <?php echo base_url()?>//assets/img/s4.jpg" alt="Avatar" class="image2" style="width: 125%"/>
                                        <div class="overlay">
                                        <div class="text2"><b>Steak House</b></div>
                                        </div>
                                </div>
                            </div>
                           
                            
                           
                        </div>
                        <div class="row">
                            
                            
                                <div class="col-sm-3">
                                <div class="container">
                                    <img src=" <?php echo base_url()?>//assets/img/s6.jpg" alt="Avatar" class="image2" style="width: 125%"/>
                                        <div class="overlay">
                                        <div class="text2"><b>Sushi Food</b></div>
                                        </div>
                                </div>
                            </div>
                                <div class="col-sm-3">
                                <div class="container">
                                    <img src=" <?php echo base_url()?>//assets/img/s7.jpg" alt="Avatar" class="image2" style="width: 125%"/>
                                        <div class="overlay">
                                        <div class="text2"><b>Mexican Food</b></div>
                                        </div>
                                </div>
                            </div>
                                <div class="col-sm-3">
                                <div class="container">
                                    <img src=" <?php echo base_url()?>//assets/img/s8.jpg" alt="Avatar" class="image2" style="width: 125%"/>
                                        <div class="overlay">
                                        <div class="text2"><b>Chinese Food</b></div>
                                        </div>
                                </div>
                            </div>
                                <div class="col-sm-3">
                                <div class="container">
                                    <img src=" <?php echo base_url()?>//assets/img/s9.jpg" alt="Avatar" class="image2" style="width: 125%"/>
                                        <div class="overlay">
                                        <div class="text2"><b>PIZZA</b></div>
                                        </div>
                                </div>
                            </div>
                        </div>
    <hr>
    
    
    
    
     <section id="contact">
      <div class="container-full">
        <div class="row">
          <div class="col-lg-8 mx-auto text-center">
            <h2 class="section-heading">ABOUT US!</h2>
            <hr class="my-4">
            <p class="mb-5">This website was made for Database Management System.<br> Still under construction.<br> MADE BY <b>JUMAR, TANJEEB AND ZAHID</b></p>
          </div>
        </div>
        <div class="row">
          <div class="col-lg-4 ml-auto text-center">
            <i class="fa fa-phone fa-3x mb-3 sr-contact"></i>
            <p>123-456-6789</p>
          </div>
          <div class="col-lg-4 mr-auto text-center">
            <i class="fa fa-envelope-o fa-3x mb-3 sr-contact"></i>
            <p>
              <a href="mailto:your-email@your-domain.com">jumar.alam@northsouth.edu</a>
            </p>
          </div>
        </div>
      </div>
    </section>

   

    
   

   

    
    </body>
    </head>
</html>