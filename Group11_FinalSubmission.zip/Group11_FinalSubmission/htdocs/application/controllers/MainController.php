<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class MainController extends CI_Controller {


	public function index()
	{
		$this->load->view('index');
	}

	public function order()
	{
		$this->load->view('order');
	}

	public function login()
	{
		$this->load->view('login');
	}

	public function signup()
	{
		$this->load->view('signup');
	}

	public function reservation()
	{
		$this->load->view('reservation');
	}

	function signupprocess(){
	$this->load->model('MainModel');

	if($this->MainModel->storeDataToDB()){
			//$this->load->view('profile');
		}else {
			$this->load->view('signup');
		
		}
	
	}


	function loginprocess(){
		$this->load->model('MainModel');
		if($this->MainModel->checkLogin()){
			$this->load->view('index');
		}else {
			$this->load->view('login');
		}
	}
}
