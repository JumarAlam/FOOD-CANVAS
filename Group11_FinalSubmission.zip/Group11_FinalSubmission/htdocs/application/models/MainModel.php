<?php
	class MainModel extends CI_Model{
		

		function storeDataToDB(){
			$name = $this->input->post('name');
			$phone = $this->input->post('phone');
			$password = $this->input->post('pass');
			$email = $this->input->post('email');
			$address = $this->input->post('address');			

			$sql = "INSERT INTO users (Name, Address, Phone_Number,Password, Email) VALUES('$name', '$address', '$phone', '$password','$email')";

			//$msn= "select username from users where username like '%$username';"
			
					$this->db->query($sql);

		}

		

		function checkLogin(){
			$email = $this->input->post('email');
			$password = $this->input->post('pass');

			$sql = "SELECT * FROM users WHERE Email = '$email' AND Password ='$password'";
			if(($this->db->query($sql)->num_rows())>0){
				return true;
			}else {
				return false;
			}
		}

	}
?>