-- Created by Vertabelo (http://vertabelo.com)
-- Last modification date: 2018-05-01 08:53:17.124

-- tables
-- Table: Food_Item
CREATE TABLE Food_Item (
    Food_ID integer  NOT NULL,
    Food_name char(25)  NOT NULL,
    Food_Type_Type_Name char(25)  NOT NULL,
    CONSTRAINT Food_Item_pk PRIMARY KEY (Food_ID)
) ;

-- Table: Food_Type
CREATE TABLE Food_Type (
    Type_Name char(25)  NOT NULL,
    CONSTRAINT Food_Type_pk PRIMARY KEY (Type_Name)
) ;

-- Table: Orders
CREATE TABLE Orders (
    User_User_ID integer  NOT NULL,
    Shop_Shop_ID integer  NOT NULL,
    Order_ID integer  NOT NULL,
    CONSTRAINT Orders_pk PRIMARY KEY (Order_ID)
) ;

-- Table: Rate
CREATE TABLE Rate (
    Rating integer  NOT NULL,
    CONSTRAINT Rate_pk PRIMARY KEY (Rating)
) ;

-- Table: Reservation
CREATE TABLE Reservation (
    User_User_ID integer  NOT NULL,
    Shop_Shop_ID integer  NOT NULL,
    Reservation_ID integer  NOT NULL,
    CONSTRAINT Reservation_pk PRIMARY KEY (Reservation_ID)
) ;

-- Table: Shop
CREATE TABLE Shop (
    Shop_ID integer  NOT NULL,
    Name char(25)  NOT NULL,
    Address char(40)  NOT NULL,
    Phone_Number integer  NOT NULL,
    Rate_Rating integer  NOT NULL,
    Shop_Type_Type_Name char(25)  NOT NULL,
    CONSTRAINT Shop_pk PRIMARY KEY (Shop_ID)
) ;

-- Table: Shop_FdItm_Junction
CREATE TABLE Shop_FdItm_Junction (
    Shop_Shop_ID integer  NOT NULL,
    Food_Item_Food_ID integer  NOT NULL,
    Price float(6)  NOT NULL,
    Rate_Rating integer  NOT NULL
) ;

-- Table: Shop_Type
CREATE TABLE Shop_Type (
    Type_Name char(25)  NOT NULL,
    CONSTRAINT Shop_Type_pk PRIMARY KEY (Type_Name)
) ;

-- Table: Users
CREATE TABLE Users (
    User_ID integer  NOT NULL,
    Name char(25)  NOT NULL,
    Address char(40)  NOT NULL,
    Phone_Number integer  NOT NULL,
    Password char(15)  NOT NULL,
    CONSTRAINT Users_pk PRIMARY KEY (User_ID)
) ;

-- foreign keys
-- Reference: Food_Item_Food_Type (table: Food_Item)
ALTER TABLE Food_Item ADD CONSTRAINT Food_Item_Food_Type
    FOREIGN KEY (Food_Type_Type_Name)
    REFERENCES Food_Type (Type_Name);

-- Reference: Order_Shop (table: Orders)
ALTER TABLE Orders ADD CONSTRAINT Order_Shop
    FOREIGN KEY (Shop_Shop_ID)
    REFERENCES Shop (Shop_ID);

-- Reference: Order_User (table: Orders)
ALTER TABLE Orders ADD CONSTRAINT Order_User
    FOREIGN KEY (User_User_ID)
    REFERENCES Users (User_ID);

-- Reference: Reservation_Shop (table: Reservation)
ALTER TABLE Reservation ADD CONSTRAINT Reservation_Shop
    FOREIGN KEY (Shop_Shop_ID)
    REFERENCES Shop (Shop_ID);

-- Reference: Reservation_User (table: Reservation)
ALTER TABLE Reservation ADD CONSTRAINT Reservation_User
    FOREIGN KEY (User_User_ID)
    REFERENCES Users (User_ID);

-- Reference: Shop_FoodItem_Junction (table: Shop_FdItm_Junction)
ALTER TABLE Shop_FdItm_Junction ADD CONSTRAINT Shop_FoodItem_Junction
    FOREIGN KEY (Food_Item_Food_ID)
    REFERENCES Food_Item (Food_ID);

-- Reference: Shop_FoodItem_Junction_Rate (table: Shop_FdItm_Junction)
ALTER TABLE Shop_FdItm_Junction ADD CONSTRAINT Shop_FoodItem_Junction_Rate
    FOREIGN KEY (Rate_Rating)
    REFERENCES Rate (Rating);

-- Reference: Shop_FoodItem_Junction_Shop (table: Shop_FdItm_Junction)
ALTER TABLE Shop_FdItm_Junction ADD CONSTRAINT Shop_FoodItem_Junction_Shop
    FOREIGN KEY (Shop_Shop_ID)
    REFERENCES Shop (Shop_ID);

-- Reference: Shop_Rate (table: Shop)
ALTER TABLE Shop ADD CONSTRAINT Shop_Rate
    FOREIGN KEY (Rate_Rating)
    REFERENCES Rate (Rating);

-- Reference: Shop_Shop_Type (table: Shop)
ALTER TABLE Shop ADD CONSTRAINT Shop_Shop_Type
    FOREIGN KEY (Shop_Type_Type_Name)
    REFERENCES Shop_Type (Type_Name);

-- End of file.

